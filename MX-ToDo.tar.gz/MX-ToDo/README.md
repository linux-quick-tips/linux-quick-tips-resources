# ToDo

There are two variants of this conky: todo.conf and todo_sys.conf. The first displays date, time and recorded tasks, while the second adds a certain amount of concise system info. 

We recommend that you use Conky Manager for management: select the conky you want to change and then click the gear icon on the top bar that is next to the pencil icon. The dialog box that appears makes it easy to change Location, Size, Transparency, Time and Network. 

To set up your task list:
1) create a new file in your Documents folder named "todo.txt" (~/Documents/todo.txt)
2) Enter tasks that you want to see, then save the file
3) When you save the file, your tasks will quickly show up on the desktop
4) Optional: create a link to the file on the desktop, panel or dock
